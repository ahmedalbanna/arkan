--
-- PostgreSQL database dump
--

\restrict HUoovkFmmcWwxznARsejM3ubqpz3yYbyPO2lGKhPKsg4QKuyR4KFtZcpVKPpfh5

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hdb_catalog; Type: SCHEMA; Schema: -; Owner: arkan_user
--

CREATE SCHEMA hdb_catalog;


ALTER SCHEMA hdb_catalog OWNER TO arkan_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: TransactionStatus; Type: TYPE; Schema: public; Owner: arkan_user
--

CREATE TYPE public."TransactionStatus" AS ENUM (
    'PENDING',
    'VERIFIED',
    'REJECTED',
    'COMPLETED'
);


ALTER TYPE public."TransactionStatus" OWNER TO arkan_user;

--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: arkan_user
--

CREATE TYPE public."TransactionType" AS ENUM (
    'PURCHASE',
    'GIFT',
    'REFUND',
    'BONUS'
);


ALTER TYPE public."TransactionType" OWNER TO arkan_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: arkan_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'USER',
    'ADMIN',
    'SUPER_ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO arkan_user;

--
-- Name: gen_hasura_uuid(); Type: FUNCTION; Schema: hdb_catalog; Owner: arkan_user
--

CREATE FUNCTION hdb_catalog.gen_hasura_uuid() RETURNS uuid
    LANGUAGE sql
    AS $$select gen_random_uuid()$$;


ALTER FUNCTION hdb_catalog.gen_hasura_uuid() OWNER TO arkan_user;

--
-- Name: calculate_total_spent(uuid); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.calculate_total_spent(user_uuid uuid) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    total NUMERIC;
BEGIN
    SELECT COALESCE(SUM(amount), 0) INTO total
    FROM transactions
    WHERE user_id = user_uuid::text
    AND status IN ('VERIFIED', 'COMPLETED')
    AND type = 'PURCHASE';
    
    RETURN total;
END;
$$;


ALTER FUNCTION public.calculate_total_spent(user_uuid uuid) OWNER TO arkan_user;

--
-- Name: current_user_id(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.current_user_id() RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Try to get from Hasura JWT claims first
    BEGIN
        RETURN current_setting('request.jwt.claims', true)::json->>'x-hasura-user-id';
    EXCEPTION
        WHEN OTHERS THEN
            -- Fallback to app setting (for Prisma/direct connections)
            RETURN current_setting('app.current_user_id', true);
    END;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;


ALTER FUNCTION public.current_user_id() OWNER TO arkan_user;

--
-- Name: get_credit_summary(uuid); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.get_credit_summary(user_uuid uuid) RETURNS TABLE(total_credits integer, total_debits integer, current_balance integer, transaction_count bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(CASE WHEN type = 'credit' THEN amount ELSE 0 END), 0)::INTEGER as total_credits,
        COALESCE(SUM(CASE WHEN type = 'debit' THEN amount ELSE 0 END), 0)::INTEGER as total_debits,
        (SELECT credits FROM users WHERE id = user_uuid::text) as current_balance,
        COUNT(*) as transaction_count
    FROM credit_ledger
    WHERE user_id = user_uuid::text;
END;
$$;


ALTER FUNCTION public.get_credit_summary(user_uuid uuid) OWNER TO arkan_user;

--
-- Name: get_user_credits(uuid); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.get_user_credits(user_uuid uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    user_credits INTEGER;
BEGIN
    SELECT credits INTO user_credits
    FROM users
    WHERE id = user_uuid::text;
    
    RETURN COALESCE(user_credits, 0);
END;
$$;


ALTER FUNCTION public.get_user_credits(user_uuid uuid) OWNER TO arkan_user;

--
-- Name: get_user_stats(uuid); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.get_user_stats(user_uuid uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    stats JSON;
BEGIN
    SELECT json_build_object(
        'user_id', user_uuid,
        'total_projects', (SELECT COUNT(*) FROM projects WHERE user_id = user_uuid::text),
        'total_transactions', (SELECT COUNT(*) FROM transactions WHERE user_id = user_uuid::text),
        'total_spent', (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE user_id = user_uuid::text AND status IN ('VERIFIED', 'COMPLETED')),
        'current_credits', (SELECT credits FROM users WHERE id = user_uuid::text),
        'total_notifications', (SELECT COUNT(*) FROM notifications WHERE user_id = user_uuid::text),
        'unread_notifications', (SELECT COUNT(*) FROM notifications WHERE user_id = user_uuid::text AND is_read = false),
        'member_since', (SELECT created_at FROM users WHERE id = user_uuid::text),
        'last_login', (SELECT last_login_at FROM users WHERE id = user_uuid::text)
    ) INTO stats;
    
    RETURN stats;
END;
$$;


ALTER FUNCTION public.get_user_stats(user_uuid uuid) OWNER TO arkan_user;

--
-- Name: is_admin(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.is_admin() RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    hasura_role TEXT;
BEGIN
    -- Try to get role from Hasura JWT first
    BEGIN
        hasura_role := current_setting('request.jwt.claims', true)::json->>'x-hasura-role';
        IF hasura_role IN ('ADMIN', 'SUPER_ADMIN') THEN
            RETURN TRUE;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN NULL;
    END;

    -- Fallback: check database
    SELECT role INTO user_role
    FROM users
    WHERE id = current_user_id();
    
    RETURN user_role IN ('ADMIN', 'SUPER_ADMIN');
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END;
$$;


ALTER FUNCTION public.is_admin() OWNER TO arkan_user;

--
-- Name: log_credit_change(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.log_credit_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only log if credits actually changed
    IF NEW.credits != OLD.credits THEN
        INSERT INTO credit_ledger (
            id,
            user_id,
            type,
            amount,
            balance,
            reason,
            reference_type,
            created_at
        ) VALUES (
            gen_random_uuid()::text,
            NEW.id,
            CASE 
                WHEN NEW.credits > OLD.credits THEN 'credit'
                ELSE 'debit'
            END,
            ABS(NEW.credits - OLD.credits),
            NEW.credits,
            'Automatic credit adjustment',
            'user_update',
            CURRENT_TIMESTAMP
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_credit_change() OWNER TO arkan_user;

--
-- Name: owns_resource(text); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.owns_resource(resource_user_id text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN resource_user_id = current_user_id() OR is_admin();
END;
$$;


ALTER FUNCTION public.owns_resource(resource_user_id text) OWNER TO arkan_user;

--
-- Name: process_verified_transaction(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.process_verified_transaction() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Only process when status changes to VERIFIED or COMPLETED
    IF NEW.status IN ('VERIFIED', 'COMPLETED') AND OLD.status = 'PENDING' THEN
        -- Update user credits
        UPDATE users 
        SET credits = credits + NEW.credits
        WHERE id = NEW.user_id;
        
        -- Add entry to credit ledger with transaction reference
        INSERT INTO credit_ledger (
            id,
            user_id,
            type,
            amount,
            balance,
            reason,
            reference_id,
            reference_type,
            metadata,
            created_at
        ) 
        SELECT 
            gen_random_uuid()::text,
            NEW.user_id,
            'credit',
            NEW.credits,
            u.credits,
            CONCAT('Transaction ', NEW.type, ' verified'),
            NEW.id,
            'transaction',
            jsonb_build_object(
                'transaction_type', NEW.type,
                'amount', NEW.amount,
                'payment_method', NEW.payment_method
            ),
            CURRENT_TIMESTAMP
        FROM users u
        WHERE u.id = NEW.user_id;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.process_verified_transaction() OWNER TO arkan_user;

--
-- Name: refresh_all_materialized_views(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.refresh_all_materialized_views() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY user_statistics;
  REFRESH MATERIALIZED VIEW CONCURRENTLY project_analytics;
END;
$$;


ALTER FUNCTION public.refresh_all_materialized_views() OWNER TO arkan_user;

--
-- Name: search_projects(text, uuid); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.search_projects(search_query text, user_uuid uuid DEFAULT NULL::uuid) RETURNS TABLE(id text, title text, description text, type text, created_at timestamp without time zone, rank real)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.title,
        p.description,
        p.type,
        p.created_at,
        ts_rank(
            to_tsvector('english', COALESCE(p.title, '') || ' ' || COALESCE(p.description, '')),
            plainto_tsquery('english', search_query)
        ) as rank
    FROM projects p
    WHERE 
        (user_uuid IS NULL OR p.user_id = user_uuid::text)
        AND to_tsvector('english', COALESCE(p.title, '') || ' ' || COALESCE(p.description, ''))
            @@ plainto_tsquery('english', search_query)
    ORDER BY rank DESC;
END;
$$;


ALTER FUNCTION public.search_projects(search_query text, user_uuid uuid) OWNER TO arkan_user;

--
-- Name: soft_delete(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.soft_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- This is a placeholder for future soft delete implementation
    -- Currently, we use Prisma's cascade deletes
    RETURN OLD;
END;
$$;


ALTER FUNCTION public.soft_delete() OWNER TO arkan_user;

--
-- Name: update_last_login(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.update_last_login() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE users 
    SET last_login_at = CURRENT_TIMESTAMP
    WHERE id = NEW.user_id;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_last_login() OWNER TO arkan_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO arkan_user;

--
-- Name: validate_credits(); Type: FUNCTION; Schema: public; Owner: arkan_user
--

CREATE FUNCTION public.validate_credits() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.credits < 0 THEN
        RAISE EXCEPTION 'Credits cannot be negative. User: %, Credits: %', NEW.id, NEW.credits;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.validate_credits() OWNER TO arkan_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hdb_action_log; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_action_log (
    id uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    action_name text,
    input_payload jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    session_variables jsonb NOT NULL,
    response_payload jsonb,
    errors jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    response_received_at timestamp with time zone,
    status text NOT NULL,
    CONSTRAINT hdb_action_log_status_check CHECK ((status = ANY (ARRAY['created'::text, 'processing'::text, 'completed'::text, 'error'::text])))
);


ALTER TABLE hdb_catalog.hdb_action_log OWNER TO arkan_user;

--
-- Name: hdb_cron_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_cron_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_cron_event_invocation_logs OWNER TO arkan_user;

--
-- Name: hdb_cron_events; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_cron_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    trigger_name text NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_cron_events OWNER TO arkan_user;

--
-- Name: hdb_metadata; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_metadata (
    id integer NOT NULL,
    metadata json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE hdb_catalog.hdb_metadata OWNER TO arkan_user;

--
-- Name: hdb_scheduled_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_scheduled_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_scheduled_event_invocation_logs OWNER TO arkan_user;

--
-- Name: hdb_scheduled_events; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_scheduled_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    webhook_conf json NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    retry_conf json,
    payload json,
    header_conf json,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    comment text,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_scheduled_events OWNER TO arkan_user;

--
-- Name: hdb_schema_notifications; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_schema_notifications (
    id integer NOT NULL,
    notification json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL,
    instance_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT hdb_schema_notifications_id_check CHECK ((id = 1))
);


ALTER TABLE hdb_catalog.hdb_schema_notifications OWNER TO arkan_user;

--
-- Name: hdb_version; Type: TABLE; Schema: hdb_catalog; Owner: arkan_user
--

CREATE TABLE hdb_catalog.hdb_version (
    hasura_uuid uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    version text NOT NULL,
    upgraded_on timestamp with time zone NOT NULL,
    cli_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    console_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    ee_client_id text,
    ee_client_secret text
);


ALTER TABLE hdb_catalog.hdb_version OWNER TO arkan_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO arkan_user;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    provider_account_id text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO arkan_user;

--
-- Name: agent_categories; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.agent_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    "order" integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.agent_categories OWNER TO arkan_user;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.agents (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category_id text NOT NULL,
    config jsonb,
    "order" integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.agents OWNER TO arkan_user;

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.api_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    token text NOT NULL,
    scopes text[] DEFAULT ARRAY[]::text[],
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp(3) without time zone,
    last_used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.api_tokens OWNER TO arkan_user;

--
-- Name: credit_ledger; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.credit_ledger (
    id text NOT NULL,
    user_id text NOT NULL,
    type text NOT NULL,
    amount integer NOT NULL,
    balance integer NOT NULL,
    reason text NOT NULL,
    reference_id text,
    reference_type text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.credit_ledger OWNER TO arkan_user;

--
-- Name: docx_templates; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.docx_templates (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    file_name text NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.docx_templates OWNER TO arkan_user;

--
-- Name: features; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.features (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    is_enabled boolean DEFAULT false NOT NULL,
    config jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.features OWNER TO arkan_user;

--
-- Name: generation_logs; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.generation_logs (
    id text NOT NULL,
    user_id text,
    flow_name text NOT NULL,
    input jsonb,
    output jsonb,
    duration integer,
    token_count integer,
    status text DEFAULT 'success'::text NOT NULL,
    error text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.generation_logs OWNER TO arkan_user;

--
-- Name: indexed_documents; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.indexed_documents (
    id text NOT NULL,
    title text NOT NULL,
    file_name text NOT NULL,
    file_type text NOT NULL,
    file_size integer NOT NULL,
    collection_name text NOT NULL,
    vector_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    metadata jsonb,
    error text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    indexed_at timestamp(3) without time zone
);


ALTER TABLE public.indexed_documents OWNER TO arkan_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    read_at timestamp(3) without time zone
);


ALTER TABLE public.notifications OWNER TO arkan_user;

--
-- Name: pptx_templates; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.pptx_templates (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    file_name text NOT NULL,
    file_url text NOT NULL,
    file_size integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.pptx_templates OWNER TO arkan_user;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.projects (
    id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    type text NOT NULL,
    language text DEFAULT 'ar'::text NOT NULL,
    content jsonb,
    metadata jsonb,
    template_id text,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO arkan_user;

--
-- Name: project_analytics; Type: MATERIALIZED VIEW; Schema: public; Owner: arkan_user
--

CREATE MATERIALIZED VIEW public.project_analytics AS
 SELECT p.id,
    p.user_id,
    p.title,
    p.type,
    jsonb_array_length(COALESCE((p.content -> 'chapters'::text), '[]'::jsonb)) AS chapter_count,
    pg_column_size(p.content) AS content_size_bytes,
    p.created_at,
    p.updated_at
   FROM public.projects p
  WITH NO DATA;


ALTER TABLE public.project_analytics OWNER TO arkan_user;

--
-- Name: report_templates; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.report_templates (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    category text,
    educational_level text,
    cover_config jsonb,
    sections jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.report_templates OWNER TO arkan_user;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    session_token text NOT NULL,
    user_id text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO arkan_user;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.settings (
    id text NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    type text DEFAULT 'string'::text NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.settings OWNER TO arkan_user;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    user_id text NOT NULL,
    type public."TransactionType" NOT NULL,
    status public."TransactionStatus" DEFAULT 'PENDING'::public."TransactionStatus" NOT NULL,
    amount numeric(10,2) NOT NULL,
    credits integer NOT NULL,
    payment_method text,
    payment_ref text,
    receipt_image text,
    verified_by text,
    verified_at timestamp(3) without time zone,
    rejection_reason text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.transactions OWNER TO arkan_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text,
    email_verified timestamp(3) without time zone,
    image text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    full_name text,
    phone text,
    phone_verified timestamp(3) without time zone,
    credits integer DEFAULT 0 NOT NULL,
    total_spent numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_login_at timestamp(3) without time zone,
    password_hash text
);


ALTER TABLE public.users OWNER TO arkan_user;

--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: arkan_user
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO arkan_user;

--
-- Data for Name: hdb_action_log; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_action_log (id, action_name, input_payload, request_headers, session_variables, response_payload, errors, created_at, response_received_at, status) FROM stdin;
\.


--
-- Data for Name: hdb_cron_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_cron_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_cron_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_cron_events (id, trigger_name, scheduled_time, status, tries, created_at, next_retry_at) FROM stdin;
\.


--
-- Data for Name: hdb_metadata; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_metadata (id, metadata, resource_version) FROM stdin;
1	{"sources":[{"configuration":{"connection_info":{"database_url":{"from_env":"HASURA_GRAPHQL_DATABASE_URL"},"isolation_level":"read-committed","pool_settings":{"connection_lifetime":600,"idle_timeout":180,"max_connections":50,"retries":1},"use_prepared_statements":true}},"kind":"postgres","name":"default","tables":[]}],"version":3}	1
\.


--
-- Data for Name: hdb_scheduled_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_scheduled_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_scheduled_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_scheduled_events (id, webhook_conf, scheduled_time, retry_conf, payload, header_conf, status, tries, created_at, next_retry_at, comment) FROM stdin;
\.


--
-- Data for Name: hdb_schema_notifications; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_schema_notifications (id, notification, resource_version, instance_id, updated_at) FROM stdin;
\.


--
-- Data for Name: hdb_version; Type: TABLE DATA; Schema: hdb_catalog; Owner: arkan_user
--

COPY hdb_catalog.hdb_version (hasura_uuid, version, upgraded_on, cli_state, console_state, ee_client_id, ee_client_secret) FROM stdin;
0ea23adc-6973-45c1-bf55-5eef18db3560	48	2026-02-17 15:57:43.350403+00	{}	{}	\N	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
47c704d2-221c-44f2-8150-c692eca388dd	eb24aa87626882fddcde8b36b66e2e84c10160c49ff5ba8c397ad6afa9ed8eb9	2026-02-17 16:02:15.686342+00	20260217160215_init	\N	\N	2026-02-17 16:02:15.467291+00	1
16aace84-9f6f-4347-bef8-98e9b06ab72f	af69476dd4453323447dd310252e5e80a6977c8f84345a072339e41d4a88fccf	2026-02-17 16:11:48.678381+00	20260217161148_add_password_hash	\N	\N	2026-02-17 16:11:48.674959+00	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.accounts (id, user_id, type, provider, provider_account_id, refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: agent_categories; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.agent_categories (id, name, description, icon, "order", is_active, created_at, updated_at) FROM stdin;
cmlqskk610002pkdg9ipsqjlg	Academic Writing	Tools for academic papers and research	📚	1	t	2026-02-17 16:02:28.25	2026-02-17 16:02:28.25
cmlqskk6k0003pkdgxlfk9sn9	Content Generation	Generate various types of content	✍️	2	t	2026-02-17 16:02:28.254	2026-02-17 16:02:28.254
cmlqskk6r0004pkdgi4g7qydg	Analysis Tools	Analyze and check content quality	🔍	3	t	2026-02-17 16:02:28.275	2026-02-17 16:02:28.275
cmlqskk6t0005pkdge3kql7gh	Project Tools	Project and documentation generators	📁	4	t	2026-02-17 16:02:28.278	2026-02-17 16:02:28.278
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.agents (id, name, description, category_id, config, "order", is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.api_tokens (id, user_id, name, token, scopes, is_active, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_ledger; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.credit_ledger (id, user_id, type, amount, balance, reason, reference_id, reference_type, metadata, created_at) FROM stdin;
b3fe3962-2257-4da1-abac-e6d1a54dc51b	cmlqskk5x0001pkdg9d0w4129	credit	50	150	Automatic credit adjustment	\N	user_update	\N	2026-02-17 16:07:39.388
1394c32f-bc9a-45ed-a68b-5156373d61a9	cmlqskk5x0001pkdg9d0w4129	debit	50	100	Automatic credit adjustment	\N	user_update	\N	2026-02-17 16:07:39.394
5a4aafe5-37b8-4a0b-87da-827fbed33e2e	cmlqskk5x0001pkdg9d0w4129	credit	50	150	Automatic credit adjustment	\N	user_update	\N	2026-02-17 16:07:59.39
be9c8465-392b-4620-bd2b-a7d0aa0f2d25	cmlqskk5x0001pkdg9d0w4129	debit	50	100	Automatic credit adjustment	\N	user_update	\N	2026-02-17 16:07:59.395
\.


--
-- Data for Name: docx_templates; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.docx_templates (id, key, name, description, file_name, file_url, file_size, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: features; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.features (id, key, name, description, is_enabled, config, created_at, updated_at) FROM stdin;
cmlqskk6w0006pkdggdf4b8kv	rag_enabled	RAG System	Enable RAG-powered generation	t	\N	2026-02-17 16:02:28.28	2026-02-17 16:02:28.28
cmlqskk6z0007pkdg38tkmqzy	payment_enabled	Payment System	Enable payment processing	t	\N	2026-02-17 16:02:28.283	2026-02-17 16:02:28.283
cmlqskk700008pkdgq5hfr0wf	notifications_enabled	Notifications	Enable push notifications	t	\N	2026-02-17 16:02:28.285	2026-02-17 16:02:28.285
\.


--
-- Data for Name: generation_logs; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.generation_logs (id, user_id, flow_name, input, output, duration, token_count, status, error, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: indexed_documents; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.indexed_documents (id, title, file_name, file_type, file_size, collection_name, vector_count, status, metadata, error, created_at, updated_at, indexed_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.notifications (id, user_id, title, message, type, is_read, metadata, created_at, read_at) FROM stdin;
\.


--
-- Data for Name: pptx_templates; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.pptx_templates (id, key, name, description, file_name, file_url, file_size, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.projects (id, user_id, title, description, type, language, content, metadata, template_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: report_templates; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.report_templates (id, key, name, description, category, educational_level, cover_config, sections, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.sessions (id, session_token, user_id, expires) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.settings (id, key, value, type, description, is_public, created_at, updated_at) FROM stdin;
cmlqskk720009pkdg8p5jxlgo	credits_per_dollar	10	number	Credits awarded per dollar spent	t	2026-02-17 16:02:28.287	2026-02-17 16:02:28.287
cmlqskk75000apkdgsrqlpowc	min_purchase_amount	5	number	Minimum purchase amount in dollars	t	2026-02-17 16:02:28.29	2026-02-17 16:02:28.29
cmlqskk77000bpkdgd4ohszt4	max_purchase_amount	500	number	Maximum purchase amount in dollars	t	2026-02-17 16:02:28.291	2026-02-17 16:02:28.291
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.transactions (id, user_id, type, status, amount, credits, payment_method, payment_ref, receipt_image, verified_by, verified_at, rejection_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.users (id, name, email, email_verified, image, role, full_name, phone, phone_verified, credits, total_spent, created_at, updated_at, last_login_at, password_hash) FROM stdin;
cmlqskk5x0001pkdg9d0w4129	Test User	test@arkan.dev	2026-02-17 16:02:28.243	\N	USER	Test User Account	\N	\N	100	0.00	2026-02-17 16:02:28.245	2026-02-17 16:07:59.395	\N	\N
cmlqskk5h0000pkdgw0rzh95u	Admin User	admin@arkan.dev	2026-02-17 16:13:08.774	\N	ADMIN	System Administrator	\N	\N	10000	0.00	2026-02-17 16:02:28.229	2026-02-17 16:13:08.776	\N	$2b$10$FOvUThNlIm8O0jgV1kk5KOILXmBLcRK3AGqebWbY/vITiz/GwfwnS
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: arkan_user
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: user_statistics; Type: MATERIALIZED VIEW; Schema: public; Owner: arkan_user
--

CREATE MATERIALIZED VIEW public.user_statistics AS
 SELECT u.id,
    u.email,
    u.name,
    u.role,
    u.credits,
    u.total_spent,
    count(DISTINCT p.id) AS total_projects,
    count(DISTINCT t.id) AS total_transactions,
    COALESCE(sum(t.amount), (0)::numeric) AS lifetime_spent,
    u.created_at AS member_since,
    u.last_login_at
   FROM ((public.users u
     LEFT JOIN public.projects p ON ((p.user_id = u.id)))
     LEFT JOIN public.transactions t ON (((t.user_id = u.id) AND (t.status = 'COMPLETED'::public."TransactionStatus"))))
  GROUP BY u.id
  WITH NO DATA;


ALTER TABLE public.user_statistics OWNER TO arkan_user;

--
-- Name: hdb_action_log hdb_action_log_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_action_log
    ADD CONSTRAINT hdb_action_log_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_events hdb_cron_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_events
    ADD CONSTRAINT hdb_cron_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_metadata hdb_metadata_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_pkey PRIMARY KEY (id);


--
-- Name: hdb_metadata hdb_metadata_resource_version_key; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_resource_version_key UNIQUE (resource_version);


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_scheduled_events hdb_scheduled_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_events
    ADD CONSTRAINT hdb_scheduled_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_schema_notifications hdb_schema_notifications_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_schema_notifications
    ADD CONSTRAINT hdb_schema_notifications_pkey PRIMARY KEY (id);


--
-- Name: hdb_version hdb_version_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_version
    ADD CONSTRAINT hdb_version_pkey PRIMARY KEY (hasura_uuid);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: agent_categories agent_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.agent_categories
    ADD CONSTRAINT agent_categories_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: credit_ledger credit_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_pkey PRIMARY KEY (id);


--
-- Name: docx_templates docx_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.docx_templates
    ADD CONSTRAINT docx_templates_pkey PRIMARY KEY (id);


--
-- Name: features features_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_pkey PRIMARY KEY (id);


--
-- Name: generation_logs generation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.generation_logs
    ADD CONSTRAINT generation_logs_pkey PRIMARY KEY (id);


--
-- Name: indexed_documents indexed_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.indexed_documents
    ADD CONSTRAINT indexed_documents_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pptx_templates pptx_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.pptx_templates
    ADD CONSTRAINT pptx_templates_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: report_templates report_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.report_templates
    ADD CONSTRAINT report_templates_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_event_invocation_event_id; Type: INDEX; Schema: hdb_catalog; Owner: arkan_user
--

CREATE INDEX hdb_cron_event_invocation_event_id ON hdb_catalog.hdb_cron_event_invocation_logs USING btree (event_id);


--
-- Name: hdb_cron_event_status; Type: INDEX; Schema: hdb_catalog; Owner: arkan_user
--

CREATE INDEX hdb_cron_event_status ON hdb_catalog.hdb_cron_events USING btree (status);


--
-- Name: hdb_cron_events_unique_scheduled; Type: INDEX; Schema: hdb_catalog; Owner: arkan_user
--

CREATE UNIQUE INDEX hdb_cron_events_unique_scheduled ON hdb_catalog.hdb_cron_events USING btree (trigger_name, scheduled_time) WHERE (status = 'scheduled'::text);


--
-- Name: hdb_scheduled_event_status; Type: INDEX; Schema: hdb_catalog; Owner: arkan_user
--

CREATE INDEX hdb_scheduled_event_status ON hdb_catalog.hdb_scheduled_events USING btree (status);


--
-- Name: hdb_version_one_row; Type: INDEX; Schema: hdb_catalog; Owner: arkan_user
--

CREATE UNIQUE INDEX hdb_version_one_row ON hdb_catalog.hdb_version USING btree (((version IS NOT NULL)));


--
-- Name: accounts_provider_provider_account_id_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX accounts_provider_provider_account_id_key ON public.accounts USING btree (provider, provider_account_id);


--
-- Name: accounts_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX accounts_user_id_idx ON public.accounts USING btree (user_id);


--
-- Name: agent_categories_name_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX agent_categories_name_key ON public.agent_categories USING btree (name);


--
-- Name: agent_categories_order_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX agent_categories_order_idx ON public.agent_categories USING btree ("order");


--
-- Name: agents_category_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX agents_category_id_idx ON public.agents USING btree (category_id);


--
-- Name: agents_order_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX agents_order_idx ON public.agents USING btree ("order");


--
-- Name: api_tokens_token_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX api_tokens_token_idx ON public.api_tokens USING btree (token);


--
-- Name: api_tokens_token_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX api_tokens_token_key ON public.api_tokens USING btree (token);


--
-- Name: api_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX api_tokens_user_id_idx ON public.api_tokens USING btree (user_id);


--
-- Name: credit_ledger_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX credit_ledger_created_at_idx ON public.credit_ledger USING btree (created_at);


--
-- Name: credit_ledger_reference_id_reference_type_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX credit_ledger_reference_id_reference_type_idx ON public.credit_ledger USING btree (reference_id, reference_type);


--
-- Name: credit_ledger_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX credit_ledger_user_id_idx ON public.credit_ledger USING btree (user_id);


--
-- Name: docx_templates_key_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX docx_templates_key_idx ON public.docx_templates USING btree (key);


--
-- Name: docx_templates_key_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX docx_templates_key_key ON public.docx_templates USING btree (key);


--
-- Name: features_is_enabled_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX features_is_enabled_idx ON public.features USING btree (is_enabled);


--
-- Name: features_key_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX features_key_idx ON public.features USING btree (key);


--
-- Name: features_key_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX features_key_key ON public.features USING btree (key);


--
-- Name: generation_logs_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX generation_logs_created_at_idx ON public.generation_logs USING btree (created_at);


--
-- Name: generation_logs_flow_name_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX generation_logs_flow_name_idx ON public.generation_logs USING btree (flow_name);


--
-- Name: generation_logs_status_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX generation_logs_status_idx ON public.generation_logs USING btree (status);


--
-- Name: generation_logs_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX generation_logs_user_id_idx ON public.generation_logs USING btree (user_id);


--
-- Name: idx_credit_ledger_user_created; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_credit_ledger_user_created ON public.credit_ledger USING btree (user_id, created_at DESC);


--
-- Name: idx_project_analytics_id; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX idx_project_analytics_id ON public.project_analytics USING btree (id);


--
-- Name: idx_project_analytics_user; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_project_analytics_user ON public.project_analytics USING btree (user_id, created_at DESC);


--
-- Name: idx_projects_user_created; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_projects_user_created ON public.projects USING btree (user_id, created_at DESC);


--
-- Name: idx_projects_user_updated; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_projects_user_updated ON public.projects USING btree (user_id, updated_at DESC);


--
-- Name: idx_transactions_created_status; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_transactions_created_status ON public.transactions USING btree (created_at DESC, status);


--
-- Name: idx_transactions_user_created; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_transactions_user_created ON public.transactions USING btree (user_id, created_at DESC);


--
-- Name: idx_transactions_user_status; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_transactions_user_status ON public.transactions USING btree (user_id, status);


--
-- Name: idx_user_statistics_credits; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_user_statistics_credits ON public.user_statistics USING btree (credits DESC);


--
-- Name: idx_user_statistics_id; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX idx_user_statistics_id ON public.user_statistics USING btree (id);


--
-- Name: idx_user_statistics_spent; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_user_statistics_spent ON public.user_statistics USING btree (lifetime_spent DESC);


--
-- Name: idx_users_email_lower; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_users_email_lower ON public.users USING btree (lower(email));


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone) WHERE (phone IS NOT NULL);


--
-- Name: idx_users_role_credits; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX idx_users_role_credits ON public.users USING btree (role, credits);


--
-- Name: indexed_documents_collection_name_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX indexed_documents_collection_name_idx ON public.indexed_documents USING btree (collection_name);


--
-- Name: indexed_documents_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX indexed_documents_created_at_idx ON public.indexed_documents USING btree (created_at);


--
-- Name: indexed_documents_status_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX indexed_documents_status_idx ON public.indexed_documents USING btree (status);


--
-- Name: notifications_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX notifications_created_at_idx ON public.notifications USING btree (created_at);


--
-- Name: notifications_is_read_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX notifications_is_read_idx ON public.notifications USING btree (is_read);


--
-- Name: notifications_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX notifications_user_id_idx ON public.notifications USING btree (user_id);


--
-- Name: pptx_templates_key_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX pptx_templates_key_idx ON public.pptx_templates USING btree (key);


--
-- Name: pptx_templates_key_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX pptx_templates_key_key ON public.pptx_templates USING btree (key);


--
-- Name: projects_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX projects_created_at_idx ON public.projects USING btree (created_at);


--
-- Name: projects_status_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX projects_status_idx ON public.projects USING btree (status);


--
-- Name: projects_type_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX projects_type_idx ON public.projects USING btree (type);


--
-- Name: projects_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX projects_user_id_idx ON public.projects USING btree (user_id);


--
-- Name: report_templates_category_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX report_templates_category_idx ON public.report_templates USING btree (category);


--
-- Name: report_templates_educational_level_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX report_templates_educational_level_idx ON public.report_templates USING btree (educational_level);


--
-- Name: report_templates_key_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX report_templates_key_idx ON public.report_templates USING btree (key);


--
-- Name: report_templates_key_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX report_templates_key_key ON public.report_templates USING btree (key);


--
-- Name: sessions_session_token_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX sessions_session_token_key ON public.sessions USING btree (session_token);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: settings_key_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX settings_key_idx ON public.settings USING btree (key);


--
-- Name: settings_key_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX settings_key_key ON public.settings USING btree (key);


--
-- Name: transactions_created_at_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX transactions_created_at_idx ON public.transactions USING btree (created_at);


--
-- Name: transactions_payment_ref_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX transactions_payment_ref_key ON public.transactions USING btree (payment_ref);


--
-- Name: transactions_status_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX transactions_status_idx ON public.transactions USING btree (status);


--
-- Name: transactions_type_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX transactions_type_idx ON public.transactions USING btree (type);


--
-- Name: transactions_user_id_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX transactions_user_id_idx ON public.transactions USING btree (user_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_phone_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX users_phone_idx ON public.users USING btree (phone);


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX users_phone_key ON public.users USING btree (phone);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: arkan_user
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- Name: users log_user_credit_changes; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER log_user_credit_changes AFTER UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.log_credit_change();


--
-- Name: transactions process_transaction_verification; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER process_transaction_verification AFTER UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.process_verified_transaction();


--
-- Name: sessions track_user_login; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER track_user_login AFTER INSERT ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.update_last_login();


--
-- Name: agent_categories update_agent_categories_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_agent_categories_updated_at BEFORE UPDATE ON public.agent_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_tokens update_api_tokens_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_api_tokens_updated_at BEFORE UPDATE ON public.api_tokens FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: docx_templates update_docx_templates_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_docx_templates_updated_at BEFORE UPDATE ON public.docx_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: features update_features_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_features_updated_at BEFORE UPDATE ON public.features FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: indexed_documents update_indexed_documents_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_indexed_documents_updated_at BEFORE UPDATE ON public.indexed_documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: pptx_templates update_pptx_templates_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_pptx_templates_updated_at BEFORE UPDATE ON public.pptx_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: projects update_projects_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: report_templates update_report_templates_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_report_templates_updated_at BEFORE UPDATE ON public.report_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: settings update_settings_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_settings_updated_at BEFORE UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: transactions update_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users validate_user_credits; Type: TRIGGER; Schema: public; Owner: arkan_user
--

CREATE TRIGGER validate_user_credits BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.validate_credits();


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_cron_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: arkan_user
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_scheduled_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agents agents_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.agent_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_ledger credit_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.credit_ledger
    ADD CONSTRAINT credit_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.report_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arkan_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_categories; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.agent_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_categories agent_categories_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY agent_categories_modify_admin ON public.agent_categories USING (public.is_admin());


--
-- Name: agent_categories agent_categories_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY agent_categories_select_all ON public.agent_categories FOR SELECT USING (((is_active = true) OR public.is_admin()));


--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: agents agents_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY agents_modify_admin ON public.agents USING (public.is_admin());


--
-- Name: agents agents_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY agents_select_all ON public.agents FOR SELECT USING (((is_active = true) OR public.is_admin()));


--
-- Name: api_tokens; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.api_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: api_tokens api_tokens_delete_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY api_tokens_delete_own ON public.api_tokens FOR DELETE USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: api_tokens api_tokens_insert_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY api_tokens_insert_own ON public.api_tokens FOR INSERT WITH CHECK ((user_id = public.current_user_id()));


--
-- Name: api_tokens api_tokens_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY api_tokens_select_own ON public.api_tokens FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: api_tokens api_tokens_update_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY api_tokens_update_own ON public.api_tokens FOR UPDATE USING (((user_id = public.current_user_id()) OR public.is_admin())) WITH CHECK (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: credit_ledger; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.credit_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: credit_ledger credit_ledger_delete_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY credit_ledger_delete_admin ON public.credit_ledger FOR DELETE USING (public.is_admin());


--
-- Name: credit_ledger credit_ledger_insert_system; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY credit_ledger_insert_system ON public.credit_ledger FOR INSERT WITH CHECK (public.is_admin());


--
-- Name: credit_ledger credit_ledger_no_update; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY credit_ledger_no_update ON public.credit_ledger FOR UPDATE USING (false);


--
-- Name: credit_ledger credit_ledger_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY credit_ledger_select_own ON public.credit_ledger FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: docx_templates; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.docx_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: docx_templates docx_templates_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY docx_templates_modify_admin ON public.docx_templates USING (public.is_admin());


--
-- Name: docx_templates docx_templates_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY docx_templates_select_all ON public.docx_templates FOR SELECT USING (((is_active = true) OR public.is_admin()));


--
-- Name: features; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.features ENABLE ROW LEVEL SECURITY;

--
-- Name: features features_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY features_modify_admin ON public.features USING (public.is_admin());


--
-- Name: features features_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY features_select_all ON public.features FOR SELECT USING (true);


--
-- Name: generation_logs; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.generation_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: generation_logs generation_logs_delete_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY generation_logs_delete_admin ON public.generation_logs FOR DELETE USING (public.is_admin());


--
-- Name: generation_logs generation_logs_insert_system; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY generation_logs_insert_system ON public.generation_logs FOR INSERT WITH CHECK (true);


--
-- Name: generation_logs generation_logs_no_update; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY generation_logs_no_update ON public.generation_logs FOR UPDATE USING (public.is_admin());


--
-- Name: generation_logs generation_logs_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY generation_logs_select_own ON public.generation_logs FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin() OR (user_id IS NULL)));


--
-- Name: indexed_documents; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.indexed_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: indexed_documents indexed_documents_admin_only; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY indexed_documents_admin_only ON public.indexed_documents USING (public.is_admin());


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_delete_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY notifications_delete_own ON public.notifications FOR DELETE USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: notifications notifications_insert_system; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY notifications_insert_system ON public.notifications FOR INSERT WITH CHECK (public.is_admin());


--
-- Name: notifications notifications_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY notifications_select_own ON public.notifications FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: notifications notifications_update_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY notifications_update_own ON public.notifications FOR UPDATE USING (((user_id = public.current_user_id()) OR public.is_admin())) WITH CHECK (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: pptx_templates; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.pptx_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: pptx_templates pptx_templates_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY pptx_templates_modify_admin ON public.pptx_templates USING (public.is_admin());


--
-- Name: pptx_templates pptx_templates_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY pptx_templates_select_all ON public.pptx_templates FOR SELECT USING (((is_active = true) OR public.is_admin()));


--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: projects projects_delete_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY projects_delete_own ON public.projects FOR DELETE USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: projects projects_insert_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY projects_insert_own ON public.projects FOR INSERT WITH CHECK ((user_id = public.current_user_id()));


--
-- Name: projects projects_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY projects_select_own ON public.projects FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: projects projects_update_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY projects_update_own ON public.projects FOR UPDATE USING (((user_id = public.current_user_id()) OR public.is_admin())) WITH CHECK (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: report_templates; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.report_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: report_templates report_templates_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY report_templates_modify_admin ON public.report_templates USING (public.is_admin());


--
-- Name: report_templates report_templates_select_all; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY report_templates_select_all ON public.report_templates FOR SELECT USING (((is_active = true) OR public.is_admin()));


--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

--
-- Name: settings settings_modify_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY settings_modify_admin ON public.settings USING (public.is_admin());


--
-- Name: settings settings_select_public; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY settings_select_public ON public.settings FOR SELECT USING (((is_public = true) OR public.is_admin()));


--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions transactions_delete_admin_only; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY transactions_delete_admin_only ON public.transactions FOR DELETE USING (public.is_admin());


--
-- Name: transactions transactions_insert_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY transactions_insert_own ON public.transactions FOR INSERT WITH CHECK ((user_id = public.current_user_id()));


--
-- Name: transactions transactions_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY transactions_select_own ON public.transactions FOR SELECT USING (((user_id = public.current_user_id()) OR public.is_admin()));


--
-- Name: transactions transactions_update_admin_only; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY transactions_update_admin_only ON public.transactions FOR UPDATE USING (public.is_admin());


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: arkan_user
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_admin_update; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY users_admin_update ON public.users FOR UPDATE USING (public.is_admin());


--
-- Name: users users_delete_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY users_delete_admin ON public.users FOR DELETE USING (public.is_admin());


--
-- Name: users users_insert_admin; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY users_insert_admin ON public.users FOR INSERT WITH CHECK (public.is_admin());


--
-- Name: users users_select_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY users_select_own ON public.users FOR SELECT USING (((id = public.current_user_id()) OR public.is_admin()));


--
-- Name: users users_update_own; Type: POLICY; Schema: public; Owner: arkan_user
--

CREATE POLICY users_update_own ON public.users FOR UPDATE USING ((id = public.current_user_id())) WITH CHECK (((id = public.current_user_id()) AND (role = ( SELECT users_1.role
   FROM public.users users_1
  WHERE (users_1.id = public.current_user_id()))) AND (credits = ( SELECT users_1.credits
   FROM public.users users_1
  WHERE (users_1.id = public.current_user_id())))));


--
-- Name: project_analytics; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: arkan_user
--

REFRESH MATERIALIZED VIEW public.project_analytics;


--
-- Name: user_statistics; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: arkan_user
--

REFRESH MATERIALIZED VIEW public.user_statistics;


--
-- PostgreSQL database dump complete
--

\unrestrict HUoovkFmmcWwxznARsejM3ubqpz3yYbyPO2lGKhPKsg4QKuyR4KFtZcpVKPpfh5

